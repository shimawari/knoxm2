.class interface abstract synthetic Lcom/google/gson/stream/package-info;
.super Ljava/lang/Object;
.source "package-info.java"


# annotations
.annotation runtime Lcom/google/errorprone/annotations/CheckReturnValue;
.end annotation
