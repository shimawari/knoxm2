.class public final Landroid/support/v4/R$style;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static final TextAppearance_Compat_Notification:I = 0x7f0d004c

.field public static final TextAppearance_Compat_Notification_Info:I = 0x7f0d004d

.field public static final TextAppearance_Compat_Notification_Info_Media:I = 0x7f0d004e

.field public static final TextAppearance_Compat_Notification_Line2:I = 0x7f0d004f

.field public static final TextAppearance_Compat_Notification_Line2_Media:I = 0x7f0d0050

.field public static final TextAppearance_Compat_Notification_Media:I = 0x7f0d0051

.field public static final TextAppearance_Compat_Notification_Time:I = 0x7f0d0052

.field public static final TextAppearance_Compat_Notification_Time_Media:I = 0x7f0d0053

.field public static final TextAppearance_Compat_Notification_Title:I = 0x7f0d0054

.field public static final TextAppearance_Compat_Notification_Title_Media:I = 0x7f0d0055

.field public static final Widget_Compat_NotificationActionContainer:I = 0x7f0d005a

.field public static final Widget_Compat_NotificationActionText:I = 0x7f0d005b


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
