.class public final Landroid/support/fragment/R$drawable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/fragment/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static final notification_action_background:I = 0x7f080060

.field public static final notification_bg:I = 0x7f080061

.field public static final notification_bg_low:I = 0x7f080062

.field public static final notification_bg_low_normal:I = 0x7f080063

.field public static final notification_bg_low_pressed:I = 0x7f080064

.field public static final notification_bg_normal:I = 0x7f080065

.field public static final notification_bg_normal_pressed:I = 0x7f080066

.field public static final notification_icon_background:I = 0x7f080067

.field public static final notification_template_icon_bg:I = 0x7f080068

.field public static final notification_template_icon_low_bg:I = 0x7f080069

.field public static final notification_tile_bg:I = 0x7f08006a

.field public static final notify_panel_notification_icon_bg:I = 0x7f08006b


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
