.class public final Landroid/support/fragment/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/fragment/R$attr;,
        Landroid/support/fragment/R$bool;,
        Landroid/support/fragment/R$color;,
        Landroid/support/fragment/R$dimen;,
        Landroid/support/fragment/R$drawable;,
        Landroid/support/fragment/R$id;,
        Landroid/support/fragment/R$integer;,
        Landroid/support/fragment/R$layout;,
        Landroid/support/fragment/R$string;,
        Landroid/support/fragment/R$style;,
        Landroid/support/fragment/R$styleable;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
